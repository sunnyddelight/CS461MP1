#!/usr/bin/python
# -*- coding: utf-8 -*-
blob = """ﾇ;Ez{殲n捍f鰡bPFJ・ﾋ]-ﾛ2~・q｢b'髓・・｡ｹ轆ｲ・譯・,・祥ﾘ煜[ﾕ掻ｳ・ﾌ|ﾛﾊｵそｽXKL・(
ｳg'`鞍ﾏ・(翌・ﾅ[､t晙[sﾒo ・ﾞ錂/Lg"""
from hashlib import sha256
print "I come in peace."
