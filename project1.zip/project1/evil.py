#!/usr/bin/python
# -*- coding: utf-8 -*-
blob = """ﾇ;Ez{殲n捍f鰡bPFJ・ﾋ]-ﾛ2~・q｢b'髓・・｡9閔ｲ・譯・,・魲ﾘ煜[ﾕ掻ｳ・ﾌ|ﾛﾊｵそｽXﾋL・(
ｳg'`鞍ﾏ・(翌・ﾅ[､・ｻ[sﾒo ・ﾞnﾂ/Lg"""
from hashlib import sha256
print "Prepare to be destroyed!"
